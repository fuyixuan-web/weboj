# 在线编程Demo
<h2>项目启动过程
<li>安装nodejs环境 => https://www.runoob.com/nodejs/nodejs-install-setup.html，推荐安装最新版本
<li>进入项目安装依赖，推荐使用淘宝镜像进行安装，进入终端依次执行
<li>npm install -g cnpm -registry=https://registry.npm.taobao.org 
<li>cnpm install
<li>npm run serve
<li>完成启动





