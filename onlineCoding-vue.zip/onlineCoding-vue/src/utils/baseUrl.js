let baseUrl = ''

baseUrl = 'http://localhost:8086'


export default baseUrl
