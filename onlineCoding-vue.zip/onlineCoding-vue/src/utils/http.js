import axios from 'axios'
import baseUrl from './baseUrl'
import {MessageBox, Loading} from 'element-ui'

const TIME_OUT_MS = 60 * 1000; // 默认请求超时时间


/*
 * @param response 返回数据列表
 */
function handleResults(response) {
  let remoteResponse = response.data
  let result = {
    success: false,
    data: null,
    message: '',
  }
  if (remoteResponse.code === 200) {
    result.success = true
    result.data = remoteResponse.result
    result.message = remoteResponse.message
  } else {
    result.success = false
    result.data = remoteResponse.result
    result.message = remoteResponse.message
    console.log(remoteResponse)
    MessageBox.alert(remoteResponse.message, '提示', {
      confirmButtonText: '确 定'
    })
  }
  return result
}

function handleUrl(url) {
  url = baseUrl + url
  return url
}

/*
 * @param data 参数列表
 * @return
 */
function handleParams(data) {
  return data
}

export default {
  /*
   * @param url
   * @param data
   * @param response 请求成功时的回调函数
   * @param exception 异常的回调函数
   */
  post(url, data, response, exception) {
    let token = localStorage.getItem('token')
    axios({
      method: 'post',
      url: handleUrl(url),
      data: handleParams(data),
      timeout: TIME_OUT_MS,
      headers: {
        token: token,
        'Content-Type': 'application/json; charset=UTF-8'
      }
    }).then(
      (result) => {
        response(handleResults(result))
      }
    ).catch(
      (error) => {
        if (exception) {
          exception(error)
        } else {
          console.log(error);
        }
      }
    )
  },
  /*
   * get 请求
   * @param url
   * @param response 请求成功时的回调函数
   * @param exception 异常的回调函数
   */
  get(url, response, exception) {
    axios({
      method: 'get',
      url: handleUrl(url),
      timeout: TIME_OUT_MS,
      headers: {
        'Content-Type': 'application/json; charset=UTF-8'
      }
    }).then(
      (result) => {
        response(handleResults(result))
      }
    ).catch(
      (error) => {
        if (exception) {
          exception(error)
        } else {
          console.log(error)
        }
      }
    )
  }
}







