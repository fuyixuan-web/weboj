import Vue from "vue";
import App from "./App.vue";
import router from "./router";
import store from "./store";
import VueParticles from "vue-particles";
import VCharts from "v-charts";
import http from "./utils/http.js";
import "material-design-icons-iconfont/dist/material-design-icons.css";
import "bootstrap/dist/css/bootstrap.min.css";
import "./utils/element.js";
import "./assets/css/global.scss";
import "./assets/css/bootstrap.css";
import "./assets/css/common.css";
import "./assets/css/font.css";
import "./assets/css/iconfont.css";
import "./assets/css/materialFont.css";
import "./assets/css/theme.css";


Vue.use(VueParticles);
Vue.use(VCharts);


Vue.prototype.$http = http;
Vue.config.productionTip = "/api";
Vue.config.productionTip = false;

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount("#app");
