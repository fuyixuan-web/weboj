<template>
  <div class="app-page">
    <div class="code-boxc">
      <!-- 左侧题目区 -->
      <div class="col-md-3 pl-0 descript-coding menu-nav" :class="menuShow? 'lession-menu pr-0' : 'lession-menu-hide'">
        <transition name="el-zoom-in-left">
          <div v-show="menuShow" class="menu-nav">
            <div class="col-md-12 col-sm-12 lession-detail menu-nav">
              <div class="lession-title space" v-if="Object.keys(questionInfo).length > 0 && questionInfo.title">
                {{questionInfo.title}}<i class="el-icon-arrow-left icon-shouqi" @click="changeMenu(false)" title="收起题目"></i>
              </div>
              <div class="lession-content font-bold pb-2">【题目内容】</div>
              <div class="code-div pb-2 space pt-2 pb-2">
                <div class="code-area font-small">
                  <div class="question-content-txt" v-html="questionInfo.topicDetails"></div>
                  <el-image
                          style="width: 100%"
                          v-if="!!imgUrl"
                          :src="imgUrl"
                          :preview-src-list="preViewList">
                  </el-image>
                </div>
              </div>
              <div v-if="questionInfo && questionInfo.input">
                <div class="lession-content font-bold pt-2 pb-2">【输入形式】</div>
                <div class="code-div pb-2">
                  <div class="code-area font-small">{{questionInfo.input}}</div>
                </div>
              </div>
              <div v-if="questionInfo && questionInfo.output">
                <div class="lession-content font-bold pt-2 pb-2">【输出形式】</div>
                <div class="code-div" style="border-bottom: 1px solid #dddddd;">
                  <div class="code-area font-small"> {{questionInfo.output}}</div>
                </div>
              </div>
              <div v-for="(caseInfo, caseIndex) in questionInfo.testCaseList" :key="caseIndex">
                <div class="lession-content font-bold pb-2">【测试用例 {{ caseIndex + 1 }} 】</div>
                <div class="code-div pb-2">
                  <div class="case-info-title col-md-2 code-io pr-0  mb-3">输入：</div>
                  <div class="code-area font-small col-md-10 case-info-content mb-3" v-html="caseInfo.input"></div>
                  <div class="case-info-title col-md-2 code-io pr-0 mb-3">输出：</div>
                  <div class="code-area font-small col-md-10 case-info-content mb-3" v-html="caseInfo.output"></div>
                </div>
              </div>
            </div>
          </div>
        </transition>
      </div>
      <!-- 右侧编程区 -->
      <div class="pl-0 pr-0 write-coding" id="writeCode" :class="menuShow? 'col-md-9 col-sm-12' : 'col-md-12'">
        <div class="coding-header">
          <el-button type="primary" plain class="expand-a-btn" v-show="!menuShow" @click="changeMenu(true)" title="展开题目">展开题目<i class="el-icon-arrow-right"></i></el-button>
          <div class="coding-header-title">OnlineCoding</div>
        </div>
        <!-- 编程文本域 -->
        <div class="coding-area" v-if="codemirrorShow">
          <codemirror ref="myCm" v-model="cmCode" :options="cmOptions" class="code-mycm"></codemirror>
          <el-tooltip content="点击切换到白天模式" placement="top" v-if="cmOptions.theme === 'monokai'">
            <i class="iconfont iconbangzhuchuangyixiangfaideadengpaofaguang theme-icon sun" v-if="cmOptions.theme === 'monokai'" @click="changeTheme('neat')"></i>
          </el-tooltip>
          <el-tooltip content="点击切换到黑夜模式" placement="top" v-if="cmOptions.theme === 'neat'">
            <i class="el-icon-moon theme-icon moon" v-if="cmOptions.theme === 'neat'" @click="changeTheme('monokai')"></i>
          </el-tooltip>
        </div>
        <div class="dragLine"></div>
        <!-- 下方抽屉 -->
        <div class="coding-drawer" :class="codingResultVisible ? 'isExpaned':'isPull' ">
          <div class="change-codevisible" @click="changeCodeResultVisible">
            <i v-if="codingResultVisible" class="el-icon-arrow-down"></i>
            <i v-else class="el-icon-arrow-up"></i>
          </div>
          <div class="coding-drawer-content">
            <div class="coding-param">
              <el-tooltip content="历史记录">
                <el-button type="primary"
                           plain
                           class="code-history-btn"
                           @click="getHistoryPrint()"
                           icon="el-icon-time"
                >查看历史</el-button>
              </el-tooltip>
              <span class="code-countdown-sp">
                已提交次数&nbsp;{{questionInfo.submitId}}&nbsp;/&nbsp;{{submitLimit}}
              </span>
              <el-tooltip content="开始运行" v-if="!isRunning">
                <el-button type="primary"
                           icon="el-icon-video-play"
                           :disabled="false"
                           class="code-run-btn"
                           @click="outputCode()"
                >开始运行</el-button>
              </el-tooltip>
              <el-tooltip content="运行中" v-else>
                <el-button type="primary" :loading="isRunning" class="pull-right">运行中</el-button>
              </el-tooltip>
            </div>
            <div class="mt-3 font-bold print-title" v-show="codingResultVisible">运行结果：</div>
            <div class="code-print" v-show="codingResultVisible" :style="{ minHeight: sizeHChange(135), paddingTop: sizeHChange(4) }">
              <div v-for="(printObj, printIndex) in printList" :key="printIndex" class="pt-2 pb-3">
                <div v-if="!printObj.errMsg || (printObj.printCase !== '' && printObj.errMsg)" class="main-color">{{printObj.printCase}}</div>
                <div>
                  <span class="font-bold">评判结果：</span>{{printObj.printText}}
                </div>
                <div v-if="printObj.timeUsed !== 'running' && printObj.memoryUsed !== 'running'">
                  <div>
                    <span>评判类型：</span>{{printObj.judgeType}}
                  </div>
                  <div>
                    <span>输出结果：</span>
                    <div class="i-b-result" v-if="!!printObj.outputResult && printObj.outputResult !== '' && printObj.outputResult !== null">{{printObj.outputResult}}</div>
                  </div>
                  <div v-if="printObj.errMsg">
                    <span>错误信息：</span>{{printObj.errMsg}}
                  </div>
                  <div>
                    <span>运行耗时：</span>{{printObj.timeUsed}}ms
                    <span>占用内存：</span>{{printObj.memoryUsed}}kB。
                  </div>
                </div>
                <div>
                  <span>结果说明：</span>{{printObj.printDescription}}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import { codemirror } from 'vue-codemirror'
  import 'codemirror/lib/codemirror.css'
  // 风格
  require('codemirror/theme/monokai.css') // 夜晚
  require('codemirror/theme/neat.css') // 白天
  // keyMap
  require('codemirror/keymap/sublime')
  // 编辑中的配置
  require('codemirror/addon/edit/matchbrackets.js') // 匹配括号
  require('codemirror/addon/edit/closebrackets.js') // 匹配括号
  require('codemirror/addon/edit/matchtags.js') // 匹配标签
  require('codemirror/addon/edit/closetag.js') // 匹配标签
  require('codemirror/addon/edit/continuelist.js') //
  // 插件-提示
  require('codemirror/addon/hint/show-hint.css')
  require('codemirror/addon/hint/show-hint.js') // 显示提示
  require('codemirror/addon/hint/sql-hint') // sql提示
  require('codemirror/addon/hint/javascript-hint') // js提示
  require('codemirror/addon/hint/css-hint') // css提示
  require('codemirror/addon/hint/javascript-hint') // js提示
  require('codemirror/addon/hint/xml-hint') // Xml提示
  require('codemirror/addon/hint/html-hint') // HTML提示
  // 插件-选中行高亮
  require('codemirror/addon/selection/active-line')
  // 插件-搜索
  require('codemirror/addon/search/search') // 搜索
  require('codemirror/addon/search/searchcursor') // 搜索
  require('codemirror/addon/search/jump-to-line') // 搜索
  require('codemirror/addon/dialog/dialog') // 搜索
  require('codemirror/addon/dialog/dialog.css') // 搜索

  // 插件-代码展开收起
  require('codemirror/addon/fold/foldcode.js')
  require('codemirror/addon/fold/brace-fold.js')
  require('codemirror/addon/fold/foldgutter.css')
  require('codemirror/addon/fold/foldgutter.js')
  require('codemirror/addon/fold/xml-fold.js')
  require('codemirror/addon/fold/indent-fold.js')
  require('codemirror/addon/fold/markdown-fold.js')
  require('codemirror/addon/fold/comment-fold.js')

  // 编程语言
  require('codemirror/mode/python/python.js')
  require('codemirror/mode/javascript/javascript') // mode: "javascript"
  require('codemirror/mode/css/css') // mode: "text/css"
  require('codemirror/mode/xml/xml') // mode: "text/html"
  require('codemirror/mode/clike/clike') // mode: "text/x-java"
  require('codemirror/mode/sql/sql')

  export default {
    components: {
      codemirror
    },
    name: 'online-coding',
    created () {

    },
    mounted () {
      this.initData()
    },
    data () {
      return {
        imgUrl: '',
        preViewList: [],
        isRunning: false,
        menuShow: true,
        codemirrorShow: true,
        codingResultVisible: false,
        submitLimit: 20,
        userCode: '',
        cmCode: '/**\n' +
                ' * @author xx\n' +
                ' * Please Coding..\n' +
                ' */',
        questionInfo: {
          title: '这是题目',
          topicDetailsText: '',
          input: '',
          output: '',
          submitId: 0,
          testCaseList: []
        },
        cmOptions: {
          tabSize: 2,
          matchBrackets: true, // 匹配括号
          autoCloseBrackets: true, // 匹配括号
          matchTags: true, // 匹配标签
          mode: 'text/x-java',
          theme: 'monokai', // 主题（默认夜晚）
          lineNumbers: true, // 行号
          lineWrapping: true,
          foldGutter: true,
          gutters: ['CodeMirror-linenumbers', 'CodeMirror-foldgutter'],
          extraKeys: { 'Ctrl': 'autocomplete' }, // 按下Ctrl提示
          lineWiseCopyCut: true,
          line: true,
          scrollbarStyle: 'null',
          styleActiveLine: true, // 选中行高亮
          autofocus: true // 初始时获取焦点
        },
        printList: [
          {
            printCase: '测试用例1',
            printText: '答案正常',
            judgeType: 'JavaScript',
            outputResult: 'JavaScript No.1',
            memoryUsed: '80',
            timeUsed: '3.12',
            errMsg: '',
            printDescription: '程序运行正常，输出与答案相符，恭喜通过。'
          },
          {
            printCase: '测试用例2',
            printText: '答案错误',
            judgeType: 'JavaScript',
            outputResult: 'JavaScript No.2',
            memoryUsed: '1088',
            timeUsed: '25.55',
            errMsg: ' xx is not function !!',
            printDescription: '程序运行错误，输出与答案不符，请考虑特殊数据，算法正确性等。'
          },
        ]
      }
    },
    methods: {
      initData() {
        let _this = this
        let params = {}
        params['libraryId'] = 1
        _this.$http.post('/producer/getLib', params, res => {
          if(res.success){
            let testCaseList = []
            let questionInfo = res.data
            //解析测试用例的json字符串
            questionInfo['sampleInput'] = !!questionInfo.sampleInput ? JSON.parse(questionInfo.sampleInput) : []
            questionInfo['sampleOutput'] = !!questionInfo.sampleOutput ? JSON.parse(questionInfo.sampleOutput) : []
            for(let i in questionInfo.sampleInput){
              let testCaseObj = {}
              testCaseObj['input'] = questionInfo.sampleInput[i].input
              testCaseObj['output'] = questionInfo.sampleOutput[i].output
              testCaseList.push(testCaseObj)
            }
            questionInfo['testCaseList'] = testCaseList
            _this.questionInfo = questionInfo
          }
        },error => {
          console.log(error)
        })
      },

      changeMenu (status) {
        this.menuShow = status
      },

      changeTheme (theme) {
        this.$set(this.cmOptions, 'theme', theme)
      },

      changeCodeResultVisible() {
        this.codingResultVisible = !this.codingResultVisible
      },

      getHistoryPrint() {

      },

      outputCode() {

      },

      sizeHChange (size) {
        return window.innerHeight * size / 739 + 'px'
      },

    },
    destroyed () {

    },
    watch:{

    }
  }
</script>

<style scoped lang="scss">
  /** NormalCss **/
  body{
    margin:0;
    height: 100%;
  }
  html{
    height: 100%;
  }
  .app-page {
    width: 100%;
    height: 100vh;
  }
  .code-boxc {
    height: 100%;
  }
  .code-boxc::-webkit-scrollbar {
    width: 6px;
  }
  .code-boxc::-webkit-scrollbar-thumb {
    width: 6px;
    border-radius: 5px;
    background-color: #c1c1c1;
  }

  .row{
    width: 100%;
  }
  .f1{
    font-size:18px;
    font-family:PingFang-SC-Bold;
    font-weight:bold;
    color:#fff;
  }
  .f2{
    font-family:PingFang-SC-Regular;
    font-weight:400;
    color:#fff;
  }
  .shadow{
    box-shadow:0px 3px 15px 0px rgba(0, 0, 0, 0.14);
  }
  .m20{
    margin: 20px;
  }
  .mt20{
    margin-top:20px;
  }
  .mr20{
    margin-right:20px;
  }
  .mb20{
    margin-bottom:20px;
  }
  .ml20{
    margin-left:20px;
  }
  .center-block{
    width:1088px;
    display: block;
    margin-right: auto;
    margin-left: auto;
  }
  .center{
    display: block;
    margin-right: auto;
    margin-left: auto;
  }
  .btn-primary{
    background:#1680ff;
    border-radius:23px;
    padding-top: 14px;
    padding-bottom: 14px;
  }
  .font-bold{
    font-weight: bold;
  }
  .font-small{
    font-size: 12px;
  }
  .space{
    line-height: 18px;
    letter-spacing: 1px;
  }
  .code-bg{
    background: #f0f0f0;
  }
  .main-color{
    color:#1680ff
  }

  /** LessionMenu **/
  .lession-detail::-webkit-scrollbar{
    width:5px;
    height:10px;
    display: none;
  }
  .lession-no::-webkit-scrollbar{
    width:5px;
    height:10px;
    display: none;
  }
  .menu-nav{
    height: 100%;
  }
  .lession-menu{
    //transition: all 0.2s ease;
    border-right: 2px solid rgb(221, 221, 221);
    .lession-no{
      background-color: #6633a5;
      overflow: auto;
      .no-dot{
        background: #1680ff;
        color: #fff;
        text-align: center;
        height: 50px;
        width: 50px;
        line-height: 50px;
        border-radius: 50%;
        font-size: 18px;
        font-weight: 700;
        margin-top: 15px;
        cursor: pointer;
      }
      .no-dot:hover{
        opacity: 0.7;
      }
      .active-dot{
        background: #fff!important;
        color: #1680ff!important;
      }
    }
    .lession-detail{
      background: #f7f7f7;
      .lession-title{
        width: 100%;
        height: 60px;
        line-height: 60px;
        padding-left: 20px;
        color: #000;
        font-weight: 700;
        position: relative;
        border-bottom: 2px solid #1680ff;
        .icon-shouqi{
          position: absolute;
          right: 0;
          font-size: 20px;
          font-weight: 700;
          top: 20px;
          cursor: pointer;
        }
      }
      .lession-content{
        padding: 20px;
        color: #000;
        font-size: 14px;
      }
      .code-div{
        padding: 0px 20px 20px 20px;
        .code-area{
          padding: 10px;
          color: #000;
          background: #f0f0f0;
          min-height:35px;
          border-radius: 3px;
          white-space: pre-line;
        }
        .code-io{
          font-size: 12px;
          height: 35px;
          line-height: 35px;
          letter-spacing: 2px;
          padding-left: 5px;
        }
      }
    }
  }
  .lession-menu-hide{
    transition: all 1s ease;
    width: 0!important;
    display:none;
    .lession-no{
      display:none;
      .no-dot{
        display: none;
      }
    }
    .lession-detail{
      display:none;
      .lession-title{
        display:none;
        .icon-shouqi{
          display: none;
        }
      }
    }
  }
  .descript-coding {
    overflow-y: auto;
  }
  .descript-coding::-webkit-scrollbar {
    width: 6px;
  }
  .descript-coding::-webkit-scrollbar-thumb {
    width: 6px;
    border-radius: 5px;
    background-color: #c1c1c1;
  }
  .descript-coding::-webkit-scrollbar-thumb:hover {
    width: 6px;
    border-radius: 5px;
    background-color: #7d7d7d;
  }

  /** OnlineCoding **/
  .write-coding{
    overflow: auto;
    height: 100%;
    position: relative;
    /* 编程区域 */
    .coding-header{
      position: relative;
      width: 100%;
      height: 60px;
      line-height: 60px;
      border-bottom: 2px solid #1680ff;
      .coding-header-title {
        width: 150px;
        height: 100%;
        line-height: 60px;
        font-size: 15px;
        font-weight: 550;
        font-family: PingFang-SC-Bold;
        color: #121212;
        margin: 0 auto;
      }
      ::v-deep .el-button{
        position: absolute;
        left: 15px;
        top: 10px;
        padding: 10px 8px 10px 10px;
      }
    }
    .coding-area{
      width: 100%;
      height: calc(100% - 60px);
      position: relative;
      .code-mycm {
        border: 2px solid rgb(221, 221, 221);
        height: 100%;
        ::v-deep.CodeMirror {
          font-family: monospace;
          height: calc(100% - 48px);
          direction: ltr;
          .CodeMirror-scroll {
            overflow: scroll !important;
            margin-bottom: -30px;
            margin-right: -30px;
            height: 100%;
            outline: none;
            position: relative;
            background: rgba(134,0,255,0.03);
          }
        }
      }
    }
    .theme-icon{
      font-size: 25px;
      position: absolute;
      top: 2%;
      right: 4%;
      z-index: 999;
      cursor: pointer;
    }
    .sun{
      color: #ffff00;
    }
    .moon{
      color: #1680ff;
    }
    .dragLine {
      position: absolute;
      z-index: 999999;
      bottom: 49px;
      width: 100%;
      height: 4px;
    }
    /* 输出结果区域 */
    .coding-drawer {
      position: absolute;
      z-index: 999999;
      bottom: 1px;
      width: 100%;
      background-color: #fff;
      border-top: 1px solid #f3f3f6;
      border-bottom: 1px solid #f3f3f6;
      .change-codevisible {
        position: absolute;
        z-index: 999999;
        top: -12px;
        left: 50%;
        width: 24px;
        height: 24px;
        margin-left: -12px;
        border-radius: 12px;
        box-shadow: 0 2px 6px rgb(0 0 0 / 10%);
        color: #666;
        background-color: #fff;
        text-align: center;
        border: none;
        cursor: pointer;
        i {
          vertical-align: -1px;
          font-size: 12px;
          font-weight: 800;
          color: #1680ff;
        }
      }
      .change-codevisible:hover {
        background-color: #1680ff;
        i {
          color: #FFF;
        }
      }
      .coding-drawer-content {
        overflow-y: auto;
        width: 100%;
        height: 100%;
        padding: 4.5px 10px;
        .coding-param{
          .tip{
            margin-top: 20px;
            float: left;
            margin-left: 5px;
            color: red;
          }
          .code-history-btn::v-deep.el-button {
            padding: 10px 6px;
          }
          .code-run-btn::v-deep.el-button {
            padding: 10px 6px;
          }
        }
        .code-countdown-sp {
          display: inline-block;
          width: calc(100% - 180px);
          height: 36px;
          text-align: center;
          line-height: 36px;
          font-size: 12px;
          font-weight: 500;
          font-family: PingFang-SC-Regular;
          color: #1680ff;
        }
        .print-title{
          border-top: 2px solid rgb(221, 221, 221);
          padding-top: 10px;
          padding-bottom: 10px;
        }
        .code-print{
          width: 100%;
          color: #000;
          font-size: 12px;
          background-color: rgba(134, 0, 255, 0.03);
          border: 2px solid rgb(221, 221, 221);
          border-radius: 3px;
          padding: 0px 20px 0px 40px;
          position: relative;
          letter-spacing: 1px;
          margin-bottom: 10px;
          .i-b-result {
            display: inline-block;
            vertical-align: top;
            width: calc(100% - 80px);
          }
        }
      }
    }
    .coding-drawer::-webkit-scrollbar {
      width: 6px;
    }
    .coding-drawer::-webkit-scrollbar-thumb {
      width: 6px;
      border-radius: 5px;
      background-color: #c1c1c1;
    }
    .isExpaned {
      min-height: 286px;
      height: 286px;
    }
    .isPull {
      min-height: 48px;
      height: 48px;
    }
  }
  .case-info-title {
    width: 48px !important;
  }
  .case-info-content {
    width: calc(100% - 48px) !important;
  }

  .CodeMirror-linenumber {
    padding: 0 3px 0 5px;
    min-width: 20px;
    color: #1680ff;
    white-space: nowrap;
    font-weight: 700;
    text-align: center;
  }
</style>
